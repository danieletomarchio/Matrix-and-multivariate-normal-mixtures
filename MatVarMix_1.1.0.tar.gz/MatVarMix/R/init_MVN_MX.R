#' Initialization for Matrix-Variate Normal Mixtures
#'
#' Initializes, using a random EM-EM strategy, the ECM algorithm for fitting matrix-variate normal mixtures.
#'
#' @param Y An array with dimensions \code{p} x \code{r} x \code{num}, where \code{p} is the number of
#'     variables in the rows of each data matrix, \code{r} is the number of variables in the columns of each
#'     data matrix, and \code{num} is the number of data observations.
#' @param k An integer indicating the number of groups in the model.
#' @param nstartR An integer specifying the number of random starts to consider.
#' @param maxit A numeric value specifying the maximum number of iterations for the EM-EM strategy.
#' @param seed A numeric value specifying the seed for random generation.
#'
#' @return A list with the following elements:
#' \item{prior}{The vector of mixture weights.}
#' \item{M}{An array containing the mean matrices.}
#' \item{U}{An array containing the row covariance matrices.}
#' \item{V}{An array containing the column covariance matrices.}
#' @export
#' @examples
#' data(SimData)
#' Y <- SimData$Y
#' iniMV <- init_MVN_MX(Y = Y, k = 2, nstartR = 50)
init_MVN_MX <- function(Y, k, nstartR = 50, maxit = 5, seed = 1) {
  # Dimensions

  num <- dim(Y)[3] # sample size
  p <- nrow(Y) # rows of Y ;
  r <- ncol(Y) # columns of Y;

  # Create some objects

  prior <- matrix(NA, nstartR, k)
  M <- array(NA, dim = c(p, r, k, nstartR))
  sigmaU <- array(NA, dim = c(p, p, k, nstartR))
  sigmaV <- array(NA, dim = c(r, r, k, nstartR))

  WR <- array(NA, dim = c(p, p, k))
  WC <- array(NA, dim = c(r, r, k))

  sel <- array(NA, dim = c(p, r, k))
  dens <- array(NA, c(num, k), dimnames = list(1:(num), paste("comp.", 1:k, sep = "")))
  llk <- rep(NA, nstartR)

  ## Random initialization ##

  eu <- matrix(0, nrow = num, ncol = k)
  classy <- matrix(0, nrow = num, ncol = nstartR)
  rand.start <- matrix(0, nstartR, k)

  withr::with_seed(seed, for (i in 1:nstartR) {
    rand.start[i, ] <- sample(c(1:num), k)
  })

  for (l in 1:nstartR) {
    skip_to_next <- FALSE

    tryCatch(
      {
        ### part 0 ###

        sec <- rand.start[l, ]

        for (j in 1:k) {
          sel[, , j] <- Y[, , sec[j]]
        }

        for (j in 1:k) {
          for (i in 1:num) {
            eu[i, j] <- norm((Y[, , i] - sel[, , j]), type = "F")
          }
        }

        for (i in 1:num) {
          classy[i, l] <- which.min(eu[i, ])
        }

        z <- mclust::unmap(classy[, l])

        ### part 1 ###

        for (j in 1:k) {
          M[, , j, l] <- rowSums(Y * z[, j][slice.index(Y, 3)], dims = 2) / sum(z[, j])

          Mtemp <- array(M[, , j, l], dim = c(p, r, num))

          WR[, , j] <- tensor::tensor(aperm(tensor::tensor((Y - Mtemp) * z[, j][slice.index(Y - Mtemp, 3)], diag(r), 2, 1), c(1, 3, 2)), aperm((Y - Mtemp), c(2, 1, 3)), c(2, 3), c(1, 3))

          sigmaU[, , j, l] <- WR[, , j] / (r * sum(z[, j]))

          WC[, , j] <- tensor::tensor(aperm(tensor::tensor(aperm(Y - Mtemp, c(2, 1, 3)) * z[, j][slice.index(aperm(Y - Mtemp, c(2, 1, 3)), 3)], solve(sigmaU[, , j, l]), 2, 1), c(1, 3, 2)), (Y - Mtemp), c(2, 3), c(1, 3))

          sigmaV[, , j, l] <- WC[, , j] / (p * sum(z[, j]))
        }

        if (k == 1) {
          prior[l, ] <- 1
        } else {
          prior[l, ] <- colMeans(z)
        }

        m.iter <- 0
        loglik.new <- NULL
        ll <- NULL

        ### part 2 ###

        tryCatch(while (m.iter < maxit) {
          m.iter <- m.iter + 1

          ### E - STEP ###

          for (j in 1:k) {
            dens[, j] <- as.vector(dMVnorm(X = Y, M = M[, , j, l], U = sigmaU[, , j, l], V = sigmaV[, , j, l]))
          }

          numerator <- matrix(rep(prior[l, ], num), num, k, byrow = TRUE) * dens
          mixt.dens <- rowSums(numerator)

          post <- numerator / mixt.dens

          ### CM - STEPS ###

          for (j in 1:k) {
            M[, , j, l] <- rowSums(Y * post[, j][slice.index(Y, 3)], dims = 2) / sum(post[, j])

            Mtemp <- array(M[, , j, l], dim = c(p, r, num))

            WR[, , j] <- tensor::tensor(aperm(tensor::tensor((Y - Mtemp) * post[, j][slice.index(Y - Mtemp, 3)], solve(sigmaV[, , j, l]), 2, 1), c(1, 3, 2)), aperm((Y - Mtemp), c(2, 1, 3)), c(2, 3), c(1, 3))

            sigmaU[, , j, l] <- WR[, , j] / (r * sum(post[, j]))

            WC[, , j] <- tensor::tensor(aperm(tensor::tensor(aperm(Y - Mtemp, c(2, 1, 3)) * post[, j][slice.index(aperm(Y - Mtemp, c(2, 1, 3)), 3)], solve(sigmaU[, , j, l]), 2, 1), c(1, 3, 2)), (Y - Mtemp), c(2, 3), c(1, 3))

            sigmaV[, , j, l] <- WC[, , j] / (p * sum(post[, j]))
          }

          if (k == 1) {
            prior[l, ] <- 1
          } else {
            prior[l, ] <- colMeans(post)
          }

          for (j in 1:k) {
            dens[, j] <- as.vector(dMVnorm(X = Y, M = M[, , j, l], U = sigmaU[, , j, l], V = sigmaV[, , j, l]))
          }

          # mixture density

          numerator <- matrix(rep(prior[l, ], num), num, k, byrow = TRUE) * dens
          mixt.dens <- rowSums(numerator)
          loglik.new <- sum(log(mixt.dens))
          ll <- c(ll, loglik.new)
        }, error = function(e) {
          llk[l] <- loglik.new
        })

        llk[l] <- loglik.new

        if (any(prior[l, ] <= 0.05)) {
          llk[l] <- NA
        }
      },
      error = function(e) {
        skip_to_next <<- TRUE
      }
    )

    if (skip_to_next) {
      next
    }
  }

  df <- data.frame(llk = llk, pos = c(1:nstartR))
  df <- tidyr::drop_na(df)
  df <- df[!is.infinite(rowSums(df)), ]

  bestR <- utils::head(data.table::setorderv(df, cols = "llk", order = -1), n = 1)$pos

  return(list(prior = prior[bestR, ], M = M[, , , bestR], U = sigmaU[, , , bestR], V = sigmaV[, , , bestR]))
}
