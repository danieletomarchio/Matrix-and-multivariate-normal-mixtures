#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @useDynLib MatVarMix, .registration = TRUE
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL
