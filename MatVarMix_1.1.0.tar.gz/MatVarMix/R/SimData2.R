#' A Simulated Dataset from a Multivariate Normal Mixture Model
#'
#' A dataset generated from a multivariate normal mixture model with 2 groups.
#'
#' @usage data(SimData2)
#' @format A list containing two elements:
#' \describe{
#'   \item{1)}{A matrix with \code{num = 200} observations in the rows and \code{p = 5} variables in the columns.}
#'   \item{2)}{A vector containing the group memberships.}
#' }
"SimData2"
