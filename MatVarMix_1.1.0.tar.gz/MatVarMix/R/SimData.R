#' A Simulated Dataset from a Matrix-Variate Normal Mixture Model
#'
#' A dataset generated from a matrix-variate normal mixture model with 2 groups.
#'
#' @usage data(SimData)
#' @format A list containing two elements:
#' \describe{
#'   \item{1)}{An array with \code{p = 2} variables in the rows, \code{r = 3} variables in the columns, and \code{num = 200} matrices.}
#'   \item{2)}{A vector containing the group memberships.}
#' }
"SimData"
