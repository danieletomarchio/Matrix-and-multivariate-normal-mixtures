#' Random Number Generation for Multivariate Normal Mixtures
#'
#' Generates random numbers for multivariate normal mixtures with \code{k} components.
#'
#' @param num An integer specifying the number of random vectors to generate.
#' @param pix A numeric vector of length \code{k} containing the initial probability weights.
#' @param mu A matrix with dimensions \code{p} x \code{k} containing the mean matrices.
#' @param sigma An array with dimensions \code{p} x \code{p} x \code{k} containing the covariance matrices.
#'
#' @return A list containing the following elements:
#' \item{Y}{A matrix with dimensions \code{num} x \code{p} containing the generated data.}
#' \item{obs.class}{A vector containing the group memberships.}
#' @export
#' @examples
#' num <- 200
#' p <- 5
#' k <- 2
#' weights <- rep(1/k,k)

#' mu <- matrix(NA, p,k)
#' mu[,1] <- c(2,1,1,-1,0)
#' mu[,2] <- mu[,1] + 4

#' sigma <- array(NA,dim = c(p,p,k))
#' sigma[,,1] <- matrix(c(1.0,0.7,0.5,0.35,0.25,
#'                       0.7,1.0,0.7,0.5,0.35,
#'                       0.5,0.7,1.0,0.7,0.5,
#'                       0.35,0.50,0.70,1.0,0.70,
#'                       0.25,0.35,0.50,0.70,1.00),nrow = p, ncol = p, byrow = TRUE)
#'sigma[,,2] <- sigma[,,1]*1.2
#'SimData2 <- r_MN_MX(num = num, pix = weights, mu = mu, sigma = sigma)
r_MN_MX <- function(num, pix, mu, sigma){

  col.Y <- dim(sigma)[2]
  k <- dim(sigma)[3]

  Y <- matrix(NA, num, col.Y)

  temp <- sample(1:k,size=num,replace=TRUE,prob=pix)
  numE <- numeric(k)
  for (i in 1:k) {

    numE[i] <- length(temp[temp==i])

  }

  for (i in 1:num) {
    Y[i,] <- mnormt::rmnorm(n=1, mean = mu[, temp[i]], varcov = sigma[, , temp[i]])
  }

  return(list(Y = Y, obs.class = temp))
}
