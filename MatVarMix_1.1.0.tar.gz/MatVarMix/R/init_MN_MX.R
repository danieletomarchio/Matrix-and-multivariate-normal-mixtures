#' Initialization for Multivariate Normal Mixtures
#'
#' Initializes, using a random EM-EM strategy, the EM algorithm for fitting multivariate normal mixtures.
#'
#' @param Y A matrix with dimensions \code{num} x \code{p}, where \code{num} is the number of data observations
#'        and \code{p} is the number of variables.
#' @param k An integer indicating the number of groups in the model.
#' @param nstartR An integer specifying the number of random starts to consider.
#' @param maxit A numeric value specifying the maximum number of iterations for the EM-EM strategy.
#' @param seed A numeric value specifying the seed for random generation.
#'
#' @return A list with the following elements:
#' \item{prior}{The vector of mixture weights.}
#' \item{mu}{A matrix containing the mean matrices.}
#' \item{sigma}{An array containing the covariance matrices.}
#' @export
#' @examples
#' data(SimData2)
#' Y <- SimData2$Y
#' iniMN <- init_MN_MX(Y = Y, k = 2, nstartR = 50)
init_MN_MX <- function(Y, k, nstartR = 50, maxit = 5, seed = 1) {
  # Dimensions

  num <- nrow(Y) # sample size
  p <- ncol(Y) # rows of Y ;

  # Create some objects

  prior <- matrix(NA, nstartR, k)
  mu <- array(NA, dim = c(p, k, nstartR))
  sigma <- array(NA, dim = c(p, p, k, nstartR))

  tempW <- array(NA, dim = c(p, p, num))

  sel <- matrix(NA, p, k)
  dens <- array(NA, c(num, k), dimnames = list(1:(num), paste("comp.", 1:k, sep = "")))
  llk <- rep(NA, nstartR)

  ## Random initialization ##

  eu <- matrix(0, nrow = num, ncol = k)
  classy <- matrix(0, nrow = num, ncol = nstartR)
  rand.start <- matrix(0, nstartR, k)

  withr::with_seed(seed, for (i in 1:nstartR) {
    rand.start[i, ] <- sample(c(1:num), k)
  })

  for (l in 1:nstartR) {
    skip_to_next <- FALSE

    tryCatch(
      {
        ### part 0 ###

        sec <- rand.start[l, ]

        for (j in 1:k) {
          sel[, j] <- Y[sec[j], ]
        }

        for (j in 1:k) {
          for (i in 1:num) {
            eu[i, j] <- as.numeric(stats::dist(rbind(Y[i, ], sel[, j])))
          }
        }

        for (i in 1:(num)) {
          classy[i, l] <- which.min(eu[i, ])
        }

        z <- mclust::unmap(classy[, l])

        ### part 1 ###

        for (j in 1:k) {
          mu[, j, l] <- colSums(Y * z[, j]) / sum(z[, j])

          for (i in 1:num) {
            tempW[, , i] <- z[i, j] * (Y[i, ] - mu[, j, l]) %*% t(Y[i, ] - mu[, j, l])
          }

          sigma[, , j, l] <- rowSums(tempW, dims = 2) / sum(z[, j])
        }

        if (k == 1) {
          prior[l, ] <- 1
        } else {
          prior[l, ] <- colMeans(z)
        }

        m.iter <- 0
        loglik.new <- NULL
        ll <- NULL

        ### part 2 ###

        tryCatch(while (m.iter < maxit) {
          m.iter <- m.iter + 1

          ### E - STEP ###

          for (j in 1:k) {
            dens[, j] <- as.vector(dmnorm(X = Y, M = mu[, j, l], U = sigma[, , j, l]))
          }

          numerator <- matrix(rep(prior[l, ], num), num, k, byrow = TRUE) * dens
          mixt.dens <- rowSums(numerator)

          post <- numerator / mixt.dens

          ### M - STEP ###

          for (j in 1:k) {
            mu[, j, l] <- colSums(Y * post[, j]) / sum(post[, j])

            for (i in 1:num) {
              tempW[, , i] <- post[i, j] * (Y[i, ] - mu[, j, l]) %*% t(Y[i, ] - mu[, j, l])
            }

            sigma[, , j, l] <- rowSums(tempW, dims = 2) / sum(post[, j])
          }

          if (k == 1) {
            prior[l, ] <- 1
          } else {
            prior[l, ] <- colMeans(post)
          }

          for (j in 1:k) {
            dens[, j] <- as.vector(dmnorm(X = Y, M = mu[, j, l], U = sigma[, , j, l]))
          }

          # mixture density

          numerator <- matrix(rep(prior[l, ], num), num, k, byrow = TRUE) * dens
          mixt.dens <- rowSums(numerator)
          loglik.new <- sum(log(mixt.dens))
          ll <- c(ll, loglik.new)
        }, error = function(e) {
          llk[l] <- loglik.new
        })

        llk[l] <- loglik.new

        if (any(prior[l, ] <= 0.05)) {
          llk[l] <- NA
        }
      },
      error = function(e) {
        skip_to_next <<- TRUE
      }
    )

    if (skip_to_next) {
      next
    }
  }

  df <- data.frame(llk = llk, pos = c(1:nstartR))
  df <- tidyr::drop_na(df)
  df <- df[!is.infinite(rowSums(df)), ]

  bestR <- utils::head(data.table::setorderv(df, cols = "llk", order = -1), n = 1)$pos

  return(list(prior = prior[bestR, ], mu = mu[, , bestR], sigma = sigma[, , , bestR]))
}
