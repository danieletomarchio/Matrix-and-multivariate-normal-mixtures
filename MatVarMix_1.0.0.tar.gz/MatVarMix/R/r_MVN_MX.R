#' Random Number Generation for Matrix-Variate Normal Mixtures
#'
#' Generates random numbers for matrix-variate normal mixtures with \code{k} components.
#'
#' @param num An integer specifying the number of random matrices to generate.
#' @param pix A numeric vector of length \code{k} containing the initial probability weights.
#' @param M An array with dimensions \code{p} x \code{r} x \code{k} containing the mean matrices.
#' @param U An array with dimensions \code{p} x \code{p} x \code{k} containing the row covariance matrices.
#' @param V An array with dimensions \code{r} x \code{r} x \code{k} containing the column covariance matrices.
#'
#' @return A list containing the following elements:
#' \item{Y}{An array with dimensions \code{p} x \code{r} x \code{num} containing the generated data.}
#' \item{obs.class}{A vector containing the group memberships.}
#' @export
#' @examples
#'num <-200
#'p <- 2
#'r <- 5
#'k <- 2
#'weights <- rep(1/k, k)
#'
#'M <- array(NA, dim = c(p, r, k))
#'U <- array(NA, dim = c(p, p, k))
#'V <- array(NA, dim = c(r, r, k))
#'
#'M[,,1] <- matrix(c(2,1,1,-1,0,
#'                   4,3,4,4,2),nrow = p, ncol = r, byrow = TRUE)
#'M[,,2] <- M[,,1] + 5

#'U[,,1] <- matrix(c(1, 0.5,
#'                   0.5, 1),nrow = p, ncol = p, byrow = TRUE)
#'U[,,2] <- matrix(c(1, 0.7,
#'                   0.7, 1),nrow = p, ncol = p, byrow = TRUE)
#'
#'V[,,1] <- matrix(c(1.0,0.7,0.5,0.35,0.25,
#'                   0.7,1.0,0.7,0.5,0.35,
#'                   0.5,0.7,1.0,0.7,0.5,
#'                   0.35,0.50,0.70,1.0,0.70,
#'                   0.25,0.35,0.50,0.70,1.00),nrow = r, ncol = r, byrow = TRUE)
#'V[,,2] <- V[,,1]*1.2
#'SimData <- r_MVN_MX(num = num, pix=weights, M=M, U=U, V=V)
r_MVN_MX <- function(num, pix, M, U, V) {
  row.Y <- dim(U)[1]
  col.Y <- dim(V)[2]
  k <- dim(V)[3]

  Y <- array(NA, dim = c(row.Y, col.Y, num))

  temp <- sample(1:k, size = num, replace = TRUE, prob = pix)
  numE <- numeric(k)
  for (i in 1:k) {
    numE[i] <- length(temp[temp == i])
  }
  for (i in 1:num) {
    Y[, , i] <- LaplacesDemon::rmatrixnorm(M = M[, , temp[i]], U = U[, , temp[i]], V = V[, , temp[i]])
  }

  return(list(Y = Y, obs.class = temp))
}
