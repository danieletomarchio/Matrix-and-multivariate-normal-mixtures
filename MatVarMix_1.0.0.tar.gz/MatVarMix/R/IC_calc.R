#' Computation of Information Criteria
#'
#' Calculate AIC, AIC3, AICC, AICU, CAIC, AWE, BIC, ICL (two versions), and NEC, after a mixture model is fitted.
#'
#' @param loglik An integer specifying the log likelihood of the model.
#' @param npar An integer specifying the number of parameters of the model.
#' @param k An integer or vector indicating the number of groups in the model.
#' @param num An integer specifying the number of random matrices.
#' @param z An \code{n} x \code{k} containing the posterior probabilities.
#' @param loglik.1 An integer specifying the log likelihood of the model with \code{k = 1}. Only relavant for NEC.
#'
#' @return A list containing the values of the information criteria.
#' @export
#' @examples
#' data(SimData)
#' Y <- SimData$Y
#' iniMV <- init_MVN_MX(Y = Y, k = 2, nstartR = 50)
#' fit <- fit_MVN_MX(Y = Y, k = 2, init.par = iniMV)
#' ic  <- IC.calc(loglik = fit$loglik, npar = fit$npar, k = 2, num =  fit$num, z = fit$z)
IC.calc <- function(loglik, npar, k, num, z, loglik.1 = Inf) {
  # to be minimized

  AIC <- -2 * loglik + 2 * npar
  AIC3 <- -2 * loglik + 3 * npar

  dis <- (num / (num - npar - 1))
  if (dis > 0) {
    AICC <- -2 * loglik + (2 * npar) * dis
    AICu <- -2 * loglik + (2 * npar) * dis + num * log(dis)
  } else {
    AICC <- NA
    AICu <- NA
  }

  CAIC <- -2 * loglik + npar * (1 + log(num))

  AWE <- -2 * loglik + 2 * npar * (1.5 + log(num))
  BIC <- -2 * loglik + npar * log(num)

  z.const <- (z < 10^(-322)) * 10^(-322) + (z > 10^(-322)) * z
  hard.z <- (matrix(rep(apply(z, 1, max), k), num, k, byrow = F) == z) * 1

  EN1 <- -sum(hard.z * log(z.const))
  EN2 <- -sum(z.const * log(z.const))

  ICL1 <- BIC + 2 * EN1
  ICL2 <- BIC + 2 * EN2

  if (loglik.1 != Inf) {
    NEC <- EN2 / (loglik - loglik.1)
  } else {
    NEC <- NULL
  }

  return(list(AIC = AIC, AIC3 = AIC3, AICC = AICC, AICu = AICu, CAIC = CAIC, AWE = AWE, BIC = BIC, ICL1 = ICL1, ICL2 = ICL2, NEC = NEC))
}
