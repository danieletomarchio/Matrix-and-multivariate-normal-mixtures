#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
using namespace Rcpp;

// [[Rcpp::export]]
arma::vec dmnorm(const arma::mat& X, const arma::rowvec& M, const arma::mat& U) {
  int num = X.n_rows;  // number of observations (rows of X)
  int d = X.n_cols;    // dimensionality (columns of X)

  // Precompute the inverse and determinant of U
  arma::mat U_inv = arma::inv(U);
  double U_det = arma::det(U);

  // Allocate space for the resulting pdf values
  arma::vec pdf(num);

  // Precompute normalization factor (common for all observations)
  double normalization_const = std::pow(2 * M_PI, -d / 2.0) * std::pow(U_det, -0.5);

  for (int i = 0; i < num; i++) {
    arma::rowvec diff = X.row(i) - M;  // difference X[i,] - M
    double delta = arma::as_scalar(diff * U_inv * diff.t());  // Mahalanobis distance
    pdf(i) = normalization_const * std::exp(-0.5 * delta);  // compute the density
  }

  return pdf;
}
